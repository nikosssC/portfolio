This directory is a placeholder for FusionRedux Framework extensions.
